import { NextRequest, NextResponse } from "next/server";
import { sampleAttractions } from "@/lib/sample";
import { Attraction } from "@/lib/types";

function parseLatLong(value?: string) {
  if (!value) return null;
  const [lat, lng] = value.split(",").map(Number);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
  return { lat, lng };
}

function stripHtml(input = "") {
  return input.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
}

async function fetchNps(query: string, state: string): Promise<Attraction[]> {
  const key = process.env.NPS_API_KEY;
  if (!key) return [];

  const url = new URL("https://developer.nps.gov/api/v1/parks");
  url.searchParams.set("limit", "100");
  if (query) url.searchParams.set("q", query);
  if (state) url.searchParams.set("stateCode", state);

  const response = await fetch(url, {
    headers: { "X-Api-Key": key },
    next: { revalidate: 3600 }
  });

  if (!response.ok) return [];
  const json = await response.json();

  return (json.data ?? []).flatMap((park: any) => {
    const coords = parseLatLong(park.latLong);
    if (!coords) return [];

    const addresses = park.addresses ?? [];
    const physical = addresses.find((a: any) => a.type === "Physical") ?? addresses[0];
    const address = physical
      ? [physical.line1, physical.line2, physical.city, physical.stateCode, physical.postalCode]
          .filter(Boolean)
          .join(", ")
      : undefined;

    const images = (park.images ?? []).map((img: any) => img.url).filter(Boolean).slice(0, 6);

    return [{
      id: `nps-${park.id}`,
      name: park.fullName ?? park.name,
      description: park.description ?? "",
      state: (park.states ?? "").split(",")[0] || "",
      category: park.designation || "National Park Service",
      latitude: coords.lat,
      longitude: coords.lng,
      image: images[0],
      images,
      website: park.url,
      address,
      phone: park.contacts?.phoneNumbers?.[0]?.phoneNumber,
      source: "NPS"
    } satisfies Attraction];
  });
}

async function fetchRidb(query: string, state: string): Promise<Attraction[]> {
  const key = process.env.RIDB_API_KEY;
  if (!key) return [];

  const url = new URL("https://ridb.recreation.gov/api/v1/facilities");
  url.searchParams.set("limit", "100");
  if (query) url.searchParams.set("query", query);
  if (state) url.searchParams.set("state", state);

  const response = await fetch(url, {
    headers: { apikey: key },
    next: { revalidate: 3600 }
  });

  if (!response.ok) return [];
  const json = await response.json();

  return (json.RECDATA ?? []).flatMap((facility: any) => {
    const lat = Number(facility.FacilityLatitude);
    const lng = Number(facility.FacilityLongitude);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return [];

    const addressRow = facility.FacilityAddress?.[0];
    const address = addressRow
      ? [addressRow.FacilityStreetAddress1, addressRow.City, addressRow.AddressStateCode, addressRow.PostalCode]
          .filter(Boolean)
          .join(", ")
      : undefined;

    const images = (facility.MEDIA ?? [])
      .map((m: any) => m.URL)
      .filter(Boolean)
      .slice(0, 6);

    return [{
      id: `ridb-${facility.FacilityID}`,
      name: facility.FacilityName ?? "Recreation Site",
      description: stripHtml(facility.FacilityDescription ?? ""),
      state: addressRow?.AddressStateCode ?? "",
      category: "Federal Recreation",
      latitude: lat,
      longitude: lng,
      image: images[0],
      images,
      website: facility.FacilityReservationURL || facility.FacilityDirections,
      address,
      phone: facility.FacilityPhone,
      source: "RIDB"
    } satisfies Attraction];
  });
}

export async function GET(request: NextRequest) {
  const query = request.nextUrl.searchParams.get("q")?.trim() ?? "";
  const state = request.nextUrl.searchParams.get("state")?.trim().toUpperCase() ?? "";

  const [nps, ridb] = await Promise.all([
    fetchNps(query, state).catch(() => []),
    fetchRidb(query, state).catch(() => [])
  ]);

  let attractions = [...nps, ...ridb];

  if (!attractions.length) {
    attractions = sampleAttractions.filter((a) => {
      const q = query.toLowerCase();
      return (!q || `${a.name} ${a.description}`.toLowerCase().includes(q))
        && (!state || a.state === state);
    });
  }

  return NextResponse.json({
    attractions,
    mode: nps.length || ridb.length ? "live" : "sample"
  });
}
