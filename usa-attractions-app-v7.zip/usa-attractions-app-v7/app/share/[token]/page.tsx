export default async function SharedTripPage({
  params
}: {
  params: Promise<{ token: string }>
}) {
  const { token } = await params;

  return (
    <main className="sharedTripPage">
      <span className="eyebrow">SHARED USA ATTRACTIONS TRIP</span>
      <h1>Shared adventure</h1>
      <p>
        Share token: <code>{token.slice(0, 8)}…</code>
      </p>
      <div className="shareNotice">
        The public route is ready. Production deployment should fetch the public trip
        through a server-side Supabase client or a dedicated read-only API endpoint.
      </div>
    </main>
  );
}
